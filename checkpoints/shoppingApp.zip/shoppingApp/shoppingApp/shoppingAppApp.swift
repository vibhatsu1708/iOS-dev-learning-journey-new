//
//  shoppingAppApp.swift
//  shoppingApp
//
//  Created by Vedant Mistry on 15/12/23.
//

import SwiftUI

@main
struct shoppingAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
